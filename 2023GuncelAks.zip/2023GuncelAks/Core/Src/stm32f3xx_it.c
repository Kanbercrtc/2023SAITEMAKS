/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f3xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f3xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern CAN_HandleTypeDef hcan;
/* USER CODE BEGIN EV */
extern CAN_RxHeaderTypeDef RX_header;
extern uint8_t gelen_mesaj_kutusu[8];
int ibo;
#define DC_CAN_BASE     0x340 // bizim tritium 0x500, twente tritium 0x340
#define DC_DRIVE        0x341
#define DC_POWER    	0x342

extern uint32_t pTxMailbox;  // TX POINTER
extern uint32_t pRxMailbox;  // RX POINTER

extern uint8_t Tritium_Data_1[8];
extern uint8_t Tritium_Data_2[8];
extern uint8_t Tritium_Data_3[8];
extern uint8_t Tritium_Data_4[8];
extern uint8_t receive_cells[100];
extern bool gelenMsg_1;
extern bool gelenMsg_2;
extern bool gelenMsg_3;
extern uint16_t Global_Counter;
extern bool tim;
bool tick = false;
extern char rxBuf[1];
extern int x;

// Battery Values BEGIN

extern uint32_t pil1;
extern uint32_t pil2;
extern uint32_t pil3;
extern uint32_t pil4;
extern uint32_t pil5;
extern uint32_t pil6;
extern uint32_t pil7;
extern uint32_t pil8;
extern uint32_t pil9;
extern uint32_t pil10;
extern uint32_t pil11;
extern uint32_t pil12;
extern uint32_t pil13;
extern uint32_t pil14;
extern uint32_t pil15;
extern uint32_t pil16;
extern uint32_t pil17;
extern uint32_t pil18;
extern uint32_t pil19;
extern uint32_t pil20;
extern uint32_t pil21;
extern uint32_t pil22;
extern uint32_t pil23;
extern uint32_t pil24;
extern uint32_t pil25;
extern uint32_t pil26;
extern uint32_t pil27;
extern uint32_t pil28;
extern uint32_t pil29;
extern uint32_t pil30;
extern uint32_t pil31;
extern uint32_t pil32;


extern uint32_t pil1_Assign;
extern uint32_t pil2_Assign;
extern uint32_t pil3_Assign;
extern uint32_t pil4_Assign;
extern uint32_t pil5_Assign;
extern uint32_t pil6_Assign;
extern uint32_t pil7_Assign;
extern uint32_t pil8_Assign;
extern uint32_t pil9_Assign;
extern uint32_t pil10_Assign;
extern uint32_t pil11_Assign;
extern uint32_t pil12_Assign;
extern uint32_t pil13_Assign;
extern uint32_t pil14_Assign;
extern uint32_t pil15_Assign;
extern uint32_t pil16_Assign;
extern uint32_t pil17_Assign;
extern uint32_t pil18_Assign;
extern uint32_t pil19_Assign;
extern uint32_t pil20_Assign;
extern uint32_t pil21_Assign;
extern uint32_t pil22_Assign;
extern uint32_t pil23_Assign;
extern uint32_t pil24_Assign;
extern uint32_t pil25_Assign;
extern uint32_t pil26_Assign;
extern uint32_t pil27_Assign;
extern uint32_t pil28_Assign;
extern uint32_t pil29_Assign;
extern uint32_t pil30_Assign;
extern uint32_t pil31_Assign;
extern uint32_t pil32_Assign;


extern uint8_t battery_Value_1[8];
extern uint8_t battery_Value_2[8];
extern uint8_t battery_Value_3[8];
extern uint8_t battery_Value_4[8];
extern uint8_t battery_Value_5[8];
extern uint8_t battery_Value_6[8];
extern uint8_t battery_Value_7[8];
extern uint8_t battery_Value_8[8];
extern uint8_t battery_Value_9[8];
extern uint8_t battery_Value_10[8];
extern uint8_t battery_Value_11[8];
extern uint8_t battery_Value_12[8];
extern uint8_t battery_Value_13[8];
extern uint8_t battery_Value_14[8];
extern uint8_t battery_Value_15[8];
extern uint8_t battery_Value_16[8];
extern uint8_t battery_Value_17[8];
extern uint8_t battery_Value_18[8];
extern uint8_t battery_Value_19[8];
extern uint8_t battery_Value_20[8];
extern uint8_t battery_Value_21[8];
extern uint8_t battery_Value_22[8];
extern uint8_t battery_Value_23[8];
extern uint8_t battery_Value_24[8];
extern uint8_t battery_Value_25[8];
extern uint8_t battery_Value_26[8];
extern uint8_t battery_Value_27[8];
extern uint8_t battery_Value_28[8];
extern uint8_t battery_Value_29[8];
extern uint8_t battery_Value_30[8];
extern uint8_t battery_Value_31[8];
extern uint8_t battery_Value_32[8];


// Battery Values END


extern uint32_t BMS_Sicakligi;
extern uint32_t WH_enerji;
extern uint32_t bataryavolt;
extern uint32_t Tritium_Hiz;
extern uint32_t Tritium_Voltage;
extern uint32_t Tritium_Akim;
extern uint32_t Tritium_Motorsicakligi;
extern uint32_t Tritium_Yüzeysicakligi;
extern uint32_t current;
extern uint32_t rpm;
extern uint32_t bmsakim;
extern uint32_t hiz;
extern uint32_t hiz2;
extern uint32_t fazakim;
extern uint32_t akim;
extern uint32_t sicaklik;
extern uint32_t WH;
extern uint32_t Motor_Sicakligi;
extern uint32_t gerilim;
extern uint32_t sarjorani;
extern uint32_t guc;
extern uint32_t speed;
extern uint32_t kalanenerji;
extern uint32_t bataryagerilim;
extern uint32_t SOC;
extern uint32_t BATAKIM;
extern uint32_t sarjorani;
extern uint32_t batakimvalue;

extern uint8_t BMS_Data_1[8];
extern uint8_t WH_Data_1[8];
extern uint8_t BAT_Data_1[8];
extern uint8_t SARJ_Data_1[8];
extern uint8_t BATAKIM_Data_1[8];
extern uint8_t Tritium_Giden_1[8]; // GİDEN DATA HAVUZU
extern uint8_t Tritium_Giden_2[8];
extern uint8_t Tritium_Giden_3[8];

extern CAN_TxHeaderTypeDef TX_CAN_BASE; // GİDEN DATA İÇİN TANIMLAMA YAPTIK
extern CAN_TxHeaderTypeDef TX_DRIVE; // GİDEN DATA İÇİN TANIMLAMA YAPTIK
extern CAN_TxHeaderTypeDef TX_POWER; // GİDEN DATA İÇİN TANIMLAMA YAPTIK

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F3xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f3xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles USB low priority or CAN_RX0 interrupts.
  */
void USB_LP_CAN_RX0_IRQHandler(void)
{
  /* USER CODE BEGIN USB_LP_CAN_RX0_IRQn 0 */

  /* USER CODE END USB_LP_CAN_RX0_IRQn 0 */
  HAL_CAN_IRQHandler(&hcan);
  /* USER CODE BEGIN USB_LP_CAN_RX0_IRQn 1 */
  HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &RX_header, gelen_mesaj_kutusu);


       surus();


       ibo=999;


       if(RX_header.StdId == 0x81 ){
          	  for(int i = 7; i >= 0; i--){
          		Tritium_Data_1[7-i] = gelen_mesaj_kutusu[i];
          	  }

              uint16_t Limit_Flag;
              Limit_Flag = Tritium_Data_1[1];
            	Limit_Flag <<= 8;
            	Limit_Flag |= Tritium_Data_1[0];

            //	gerilim = Limit_Flag;


              uint16_t Active_Motor;
              	     Active_Motor = Tritium_Data_1[5];
            	     Active_Motor <<= 8;
            	     Active_Motor |= Tritium_Data_1[4];

            	  //   akim = Active_Motor;

            	memset(gelen_mesaj_kutusu,'0',sizeof(gelen_mesaj_kutusu));
              }


             else if(RX_header.StdId == 0x82 ){
          	  	   for( int i=0; i< sizeof(gelen_mesaj_kutusu);i++){
          		  	  Tritium_Data_2[i] = gelen_mesaj_kutusu[i];
            	  }

          	  	    Tritium_Voltage = Tritium_Data_2[3];
          	  	    Tritium_Voltage <<= 8;
          	  	    Tritium_Voltage |= Tritium_Data_2[2];
          	  	    Tritium_Voltage <<= 8;
          	  	    Tritium_Voltage |= Tritium_Data_2[1];
          	  	    Tritium_Voltage <<= 8;
          	  	    Tritium_Voltage |= Tritium_Data_2[0];

                   gerilim = Tritium_Voltage;


                   Tritium_Akim = Tritium_Data_2[7];
                   Tritium_Akim <<= 8;
                   Tritium_Akim |= Tritium_Data_2[6];
                   Tritium_Akim <<= 8;
                   Tritium_Akim |= Tritium_Data_2[5];
                   Tritium_Akim <<= 8;
                   Tritium_Akim |= Tritium_Data_2[4];

          		    akim = Tritium_Akim;

          		memset(gelen_mesaj_kutusu,'0',sizeof(gelen_mesaj_kutusu));
              }


            else if(RX_header.StdId == 0x83 ){
            	  for( int i=0; i< sizeof(gelen_mesaj_kutusu);i++){
            		 Tritium_Data_3[i] = gelen_mesaj_kutusu[i];
            	  }
            	  	Tritium_Hiz = Tritium_Data_3[7];
            	    Tritium_Hiz <<= 8;
            	    Tritium_Hiz |= Tritium_Data_3[6];
            	    Tritium_Hiz <<= 8;
            	    Tritium_Hiz |= Tritium_Data_3[5];
            	    Tritium_Hiz <<= 8;
            	    Tritium_Hiz |= Tritium_Data_3[4];

          		    hiz = Tritium_Hiz;


          	  memset(gelen_mesaj_kutusu,'0',sizeof(gelen_mesaj_kutusu));

            }


            else if (RX_header.StdId == 0x650)
              {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		BMS_Data_1[i] = gelen_mesaj_kutusu[i];

              	}


              	BMS_Sicakligi = BMS_Data_1[3];
              	BMS_Sicakligi <<= 8;
              	BMS_Sicakligi |= BMS_Data_1[2];
              	BMS_Sicakligi <<= 8;
              	BMS_Sicakligi |= BMS_Data_1[1];
              	BMS_Sicakligi <<= 8;
              	BMS_Sicakligi |= BMS_Data_1[0];

              	memcpy(&sicaklik,&BMS_Sicakligi,sizeof(BMS_Sicakligi));
              	//sicaklik = BMS_Sicakligi;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

              }

            else if (RX_header.StdId == 0x651)
                          {

                          	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
                          	{
                          		WH_Data_1[i] = gelen_mesaj_kutusu[i];

                          	}


                          	WH_enerji = WH_Data_1[3];
                          	WH_enerji <<= 8;
                          	WH_enerji |= WH_Data_1[2];
                          	WH_enerji <<= 8;
                          	WH_enerji |= WH_Data_1[1];
                          	WH_enerji <<= 8;
                          	WH_enerji |= WH_Data_1[0];

                          	memcpy(&kalanenerji,&WH_enerji,sizeof(WH_enerji));



                          	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

                          }


            else if (RX_header.StdId == 0x652)
                                     {

                                     	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
                                     	{
                                     		BAT_Data_1[i] = gelen_mesaj_kutusu[i];

                                     	}


                                     	bataryavolt = BAT_Data_1[3];
                                     	bataryavolt <<= 8;
                                     	bataryavolt |= BAT_Data_1[2];
                                     	bataryavolt <<= 8;
                                     	bataryavolt |= BAT_Data_1[1];
                                     	bataryavolt <<= 8;
                                     	bataryavolt |= BAT_Data_1[0];

                                     	memcpy(&bataryagerilim,&bataryavolt,sizeof(bataryavolt));



                                     	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

                                     }

            else if (RX_header.StdId == 0x653)
                                                 {

                                                 	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
                                                 	{
                                                 		SARJ_Data_1[i] = gelen_mesaj_kutusu[i];

                                                 	}


                                                 	SOC = SARJ_Data_1[3];
                                                 	SOC <<= 8;
                                                 	SOC |= SARJ_Data_1[2];
                                                 	SOC <<= 8;
                                                 	SOC |= SARJ_Data_1[1];
                                                 	SOC <<= 8;
                                                 	SOC |= SARJ_Data_1[0];

                                                 	memcpy(&sarjorani,&SOC,sizeof(SOC));



                                                 	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

                                                 }

					else if (RX_header.StdId == 0x654)
					{

					for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
					{
						BATAKIM_Data_1[i] = gelen_mesaj_kutusu[i];

					}


					BATAKIM = BATAKIM_Data_1[3];
					BATAKIM <<= 8;
					BATAKIM |= BATAKIM_Data_1[2];
					BATAKIM <<= 8;
					BATAKIM |= BATAKIM_Data_1[1];
					BATAKIM <<= 8;
					BATAKIM |= BATAKIM_Data_1[0];

					memcpy(&batakimvalue,&BATAKIM,sizeof(BATAKIM));



					memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

					}

/*
            // Read the Battery Values BEGIN

            else if (RX_header.StdId == 0x600)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_1[i] = gelen_mesaj_kutusu[i];

              	}


              	pil1_Assign = battery_Value_1[7];
              	pil1_Assign <<= 8;
              	pil1_Assign |= battery_Value_1[6];
				pil1_Assign <<= 8;
				pil1_Assign |=  battery_Value_1[5];
				pil1_Assign <<= 8;
				pil1_Assign |= battery_Value_1[4];

				pil1 = pil1_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }


            else if (RX_header.StdId == 0x601)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_2[i] = gelen_mesaj_kutusu[i];

              	}


              	pil2_Assign = battery_Value_2[7];
              	pil2_Assign <<= 8;
              	pil2_Assign |= battery_Value_2[6];
				pil2_Assign <<= 8;
				pil2_Assign |=  battery_Value_2[5];
				pil2_Assign <<= 8;
				pil2_Assign |= battery_Value_2[4];

				pil2 = pil2_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x602)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_3[i] = gelen_mesaj_kutusu[i];

              	}


              	pil3_Assign = battery_Value_3[7];
              	pil3_Assign <<= 8;
              	pil3_Assign |= battery_Value_3[6];
				pil3_Assign <<= 8;
				pil3_Assign |=  battery_Value_3[5];
				pil3_Assign <<= 8;
				pil3_Assign |= battery_Value_3[4];

				pil3 = pil3_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x603)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_4[i] = gelen_mesaj_kutusu[i];

              	}


              	pil4_Assign = battery_Value_4[7];
              	pil4_Assign <<= 8;
              	pil4_Assign |= battery_Value_4[6];
				pil4_Assign <<= 8;
				pil4_Assign |=  battery_Value_4[5];
				pil4_Assign <<= 8;
				pil4_Assign |= battery_Value_4[4];

				pil4 = pil4_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x604)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_5[i] = gelen_mesaj_kutusu[i];

              	}


              	pil5_Assign = battery_Value_5[7];
              	pil5_Assign <<= 8;
              	pil5_Assign |= battery_Value_5[6];
				pil5_Assign <<= 8;
				pil5_Assign |=  battery_Value_5[5];
				pil5_Assign <<= 8;
				pil5_Assign |= battery_Value_5[4];

				pil5 = pil5_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x605)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_6[i] = gelen_mesaj_kutusu[i];

              	}


              	pil6_Assign = battery_Value_6[7];
              	pil6_Assign <<= 8;
              	pil6_Assign |= battery_Value_6[6];
				pil6_Assign <<= 8;
				pil6_Assign |=  battery_Value_6[5];
				pil6_Assign <<= 8;
				pil6_Assign |= battery_Value_6[4];

				pil6 = pil6_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x606)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_7[i] = gelen_mesaj_kutusu[i];

              	}


              	pil7_Assign = battery_Value_7[7];
              	pil7_Assign <<= 8;
              	pil7_Assign |= battery_Value_7[6];
				pil7_Assign <<= 8;
				pil7_Assign |=  battery_Value_7[5];
				pil7_Assign <<= 8;
				pil7_Assign |= battery_Value_7[4];

				pil7 = pil7_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x607)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_8[i] = gelen_mesaj_kutusu[i];

              	}


              	pil8_Assign = battery_Value_8[7];
              	pil8_Assign <<= 8;
              	pil8_Assign |= battery_Value_8[6];
				pil8_Assign <<= 8;
				pil8_Assign |=  battery_Value_8[5];
				pil8_Assign <<= 8;
				pil8_Assign |= battery_Value_8[4];

				pil8 = pil8_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x608)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_9[i] = gelen_mesaj_kutusu[i];

              	}


              	pil9_Assign = battery_Value_9[7];
              	pil9_Assign <<= 8;
              	pil9_Assign |= battery_Value_9[6];
				pil9_Assign <<= 8;
				pil9_Assign |=  battery_Value_9[5];
				pil9_Assign <<= 8;
				pil9_Assign |= battery_Value_9[4];

				pil9 = pil9_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x609)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_10[i] = gelen_mesaj_kutusu[i];

              	}


              	pil10_Assign = battery_Value_10[7];
              	pil10_Assign <<= 8;
              	pil10_Assign |= battery_Value_10[6];
				pil10_Assign <<= 8;
				pil10_Assign |=  battery_Value_10[5];
				pil10_Assign <<= 8;
				pil10_Assign |= battery_Value_10[4];

				pil10 = pil10_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x60A)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_11[i] = gelen_mesaj_kutusu[i];

              	}


              	pil11_Assign = battery_Value_11[7];
              	pil11_Assign <<= 8;
              	pil11_Assign |= battery_Value_11[6];
				pil11_Assign <<= 8;
				pil11_Assign |=  battery_Value_11[5];
				pil11_Assign <<= 8;
				pil11_Assign |= battery_Value_11[4];

				pil11 = pil11_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x60B)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_12[i] = gelen_mesaj_kutusu[i];

              	}


              	pil12_Assign = battery_Value_12[7];
              	pil12_Assign <<= 8;
              	pil12_Assign |= battery_Value_12[6];
				pil12_Assign <<= 8;
				pil12_Assign |=  battery_Value_12[5];
				pil12_Assign <<= 8;
				pil12_Assign |= battery_Value_12[4];

				pil12 = pil12_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x60C)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_13[i] = gelen_mesaj_kutusu[i];

              	}


              	pil13_Assign = battery_Value_13[7];
              	pil13_Assign <<= 8;
              	pil13_Assign |= battery_Value_13[6];
				pil13_Assign <<= 8;
				pil13_Assign |=  battery_Value_13[5];
				pil13_Assign <<= 8;
				pil13_Assign |= battery_Value_13[4];

				pil13 = pil13_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x60D)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_14[i] = gelen_mesaj_kutusu[i];

              	}


              	pil14_Assign = battery_Value_14[7];
              	pil14_Assign <<= 8;
              	pil14_Assign |= battery_Value_14[6];
				pil14_Assign <<= 8;
				pil14_Assign |=  battery_Value_14[5];
				pil14_Assign <<= 8;
				pil14_Assign |= battery_Value_14[4];

				pil14 = pil14_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x60E)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_15[i] = gelen_mesaj_kutusu[i];

              	}


              	pil15_Assign = battery_Value_15[7];
              	pil15_Assign <<= 8;
              	pil15_Assign |= battery_Value_15[6];
				pil15_Assign <<= 8;
				pil15_Assign |=  battery_Value_15[5];
				pil15_Assign <<= 8;
				pil15_Assign |= battery_Value_15[4];

				pil15 = pil15_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x60F)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_16[i] = gelen_mesaj_kutusu[i];

              	}


              	pil16_Assign = battery_Value_16[7];
              	pil16_Assign <<= 8;
              	pil16_Assign |= battery_Value_16[6];
				pil16_Assign <<= 8;
				pil16_Assign |=  battery_Value_16[5];
				pil16_Assign <<= 8;
				pil16_Assign |= battery_Value_16[4];

				pil16 = pil16_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x610)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_17[i] = gelen_mesaj_kutusu[i];

              	}


              	pil17_Assign = battery_Value_17[7];
              	pil17_Assign <<= 8;
              	pil17_Assign |= battery_Value_17[6];
				pil17_Assign <<= 8;
				pil17_Assign |=  battery_Value_17[5];
				pil17_Assign <<= 8;
				pil17_Assign |= battery_Value_17[4];

				pil17 = pil17_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x611)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_18[i] = gelen_mesaj_kutusu[i];

              	}


              	pil18_Assign = battery_Value_18[7];
              	pil18_Assign <<= 8;
              	pil18_Assign |= battery_Value_18[6];
				pil18_Assign <<= 8;
				pil18_Assign |=  battery_Value_18[5];
				pil18_Assign <<= 8;
				pil18_Assign |= battery_Value_18[4];

				pil18 = pil18_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x612)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_19[i] = gelen_mesaj_kutusu[i];

              	}


              	pil19_Assign = battery_Value_19[7];
              	pil19_Assign <<= 8;
              	pil19_Assign |= battery_Value_19[6];
				pil19_Assign <<= 8;
				pil19_Assign |=  battery_Value_19[5];
				pil19_Assign <<= 8;
				pil19_Assign |= battery_Value_19[4];

				pil19 = pil19_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x613)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_20[i] = gelen_mesaj_kutusu[i];

              	}


              	pil20_Assign = battery_Value_20[7];
              	pil20_Assign <<= 8;
              	pil20_Assign |= battery_Value_20[6];
				pil20_Assign <<= 8;
				pil20_Assign |=  battery_Value_20[5];
				pil20_Assign <<= 8;
				pil20_Assign |= battery_Value_20[4];

				pil20 = pil20_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }


            else if (RX_header.StdId == 0x614)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_21[i] = gelen_mesaj_kutusu[i];

              	}


              	pil21_Assign = battery_Value_21[7];
              	pil21_Assign <<= 8;
              	pil21_Assign |= battery_Value_21[6];
				pil21_Assign <<= 8;
				pil21_Assign |=  battery_Value_21[5];
				pil21_Assign <<= 8;
				pil21_Assign |= battery_Value_21[4];

				pil21 = pil21_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x615)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_22[i] = gelen_mesaj_kutusu[i];

              	}


              	pil22_Assign = battery_Value_22[7];
              	pil22_Assign <<= 8;
              	pil22_Assign |= battery_Value_22[6];
				pil22_Assign <<= 8;
				pil22_Assign |=  battery_Value_22[5];
				pil22_Assign <<= 8;
				pil22_Assign |= battery_Value_22[4];

				pil22 = pil22_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x616)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_23[i] = gelen_mesaj_kutusu[i];

              	}


              	pil23_Assign = battery_Value_23[7];
              	pil23_Assign <<= 8;
              	pil23_Assign |= battery_Value_23[6];
              	pil23_Assign <<= 8;
              	pil23_Assign |=  battery_Value_23[5];
              	pil23_Assign <<= 8;
              	pil23_Assign |= battery_Value_23[4];

				pil23 = pil23_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x617)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_24[i] = gelen_mesaj_kutusu[i];

              	}


              	pil24_Assign = battery_Value_24[7];
              	pil24_Assign <<= 8;
              	pil24_Assign |= battery_Value_24[6];
              	pil24_Assign <<= 8;
              	pil24_Assign |=  battery_Value_24[5];
              	pil24_Assign <<= 8;
              	pil24_Assign |= battery_Value_24[4];

				pil24 = pil24_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }
            else if (RX_header.StdId == 0x618)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_25[i] = gelen_mesaj_kutusu[i];

              	}


              	pil25_Assign = battery_Value_25[7];
              	pil25_Assign <<= 8;
              	pil25_Assign |= battery_Value_25[6];
              	pil25_Assign <<= 8;
              	pil25_Assign |=  battery_Value_25[5];
              	pil25_Assign <<= 8;
              	pil25_Assign |= battery_Value_25[4];

				pil25 = pil25_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x619)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_26[i] = gelen_mesaj_kutusu[i];

              	}


              	pil26_Assign = battery_Value_26[7];
              	pil26_Assign <<= 8;
              	pil26_Assign |= battery_Value_26[6];
              	pil26_Assign <<= 8;
              	pil26_Assign |=  battery_Value_26[5];
              	pil26_Assign <<= 8;
              	pil26_Assign |= battery_Value_26[4];

				pil26 = pil26_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x61A)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_27[i] = gelen_mesaj_kutusu[i];

              	}


              	pil27_Assign = battery_Value_27[7];
              	pil27_Assign <<= 8;
              	pil27_Assign |= battery_Value_27[6];
              	pil27_Assign <<= 8;
				pil27_Assign |=  battery_Value_27[5];
				pil27_Assign <<= 8;
				pil27_Assign |= battery_Value_27[4];

				pil27 = pil27_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x61B)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_28[i] = gelen_mesaj_kutusu[i];

              	}


              	pil28_Assign = battery_Value_28[7];
              	pil28_Assign <<= 8;
              	pil28_Assign |= battery_Value_28[6];
              	pil28_Assign <<= 8;
              	pil28_Assign |=  battery_Value_28[5];
              	pil28_Assign <<= 8;
              	pil28_Assign |= battery_Value_28[4];

				pil28 = pil28_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x61C)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_29[i] = gelen_mesaj_kutusu[i];

              	}


              	pil29_Assign = battery_Value_29[7];
              	pil29_Assign <<= 8;
              	pil29_Assign |= battery_Value_29[6];
              	pil29_Assign <<= 8;
              	pil29_Assign |=  battery_Value_29[5];
              	pil29_Assign <<= 8;
              	pil29_Assign |= battery_Value_29[4];

				pil29 = pil29_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x61D)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_30[i] = gelen_mesaj_kutusu[i];

              	}


              	pil30_Assign = battery_Value_30[7];
              	pil30_Assign <<= 8;
              	pil30_Assign |= battery_Value_30[6];
				pil30_Assign <<= 8;
				pil30_Assign |=  battery_Value_30[5];
				pil30_Assign <<= 8;
				pil30_Assign |= battery_Value_30[4];

				pil30 = pil30_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x61E)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_31[i] = gelen_mesaj_kutusu[i];

              	}


              	pil31_Assign = battery_Value_31[7];
              	pil31_Assign <<= 8;
              	pil31_Assign |= battery_Value_31[6];
				pil31_Assign <<= 8;
				pil31_Assign |=  battery_Value_31[5];
				pil31_Assign <<= 8;
				pil31_Assign |= battery_Value_31[4];

				pil31 = pil31_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            else if (RX_header.StdId == 0x61F)
            {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		battery_Value_32[i] = gelen_mesaj_kutusu[i];

              	}


              	pil32_Assign = battery_Value_32[7];
              	pil32_Assign <<= 8;
              	pil32_Assign |= battery_Value_32[6];
				pil32_Assign <<= 8;
				pil32_Assign |=  battery_Value_32[5];
				pil32_Assign <<= 8;
				pil32_Assign |= battery_Value_32[4];

				pil32 = pil32_Assign;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

            }

            // Read the Battery Values END
*/




  /* USER CODE END USB_LP_CAN_RX0_IRQn 1 */
}

/**
  * @brief This function handles CAN_RX1 interrupt.
  */
void CAN_RX1_IRQHandler(void)
{
  /* USER CODE BEGIN CAN_RX1_IRQn 0 */

  /* USER CODE END CAN_RX1_IRQn 0 */
  HAL_CAN_IRQHandler(&hcan);
  /* USER CODE BEGIN CAN_RX1_IRQn 1 */
  HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &RX_header, gelen_mesaj_kutusu);
       surus();
       if(RX_header.StdId == 0x81 ){
          	  for(int i = 7; i >= 0; i--){
          		Tritium_Data_1[7-i] = gelen_mesaj_kutusu[i];
          	  }

              uint16_t Limit_Flag;
              Limit_Flag = Tritium_Data_1[1];
            	Limit_Flag <<= 8;
            	Limit_Flag |= Tritium_Data_1[0];

            //	gerilim = Limit_Flag;


              uint16_t Active_Motor;
              	     Active_Motor = Tritium_Data_1[5];
            	     Active_Motor <<= 8;
            	     Active_Motor |= Tritium_Data_1[4];

            	  //   akim = Active_Motor;

            	memset(gelen_mesaj_kutusu,'0',sizeof(gelen_mesaj_kutusu));
              }

             else if(RX_header.StdId == 0x82 ){
          	  	   for( int i=0; i< sizeof(gelen_mesaj_kutusu);i++){
          		  	  Tritium_Data_2[i] = gelen_mesaj_kutusu[i];
            	  }

          	  	    Tritium_Voltage = Tritium_Data_2[3];
          	  	    Tritium_Voltage <<= 8;
          	  	    Tritium_Voltage |= Tritium_Data_2[2];
          	  	    Tritium_Voltage <<= 8;
          	  	    Tritium_Voltage |= Tritium_Data_2[1];
          	  	    Tritium_Voltage <<= 8;
          	  	    Tritium_Voltage |= Tritium_Data_2[0];

                   gerilim = Tritium_Voltage;


                   Tritium_Akim = Tritium_Data_2[7];
                   Tritium_Akim <<= 8;
                   Tritium_Akim |= Tritium_Data_2[6];
                   Tritium_Akim <<= 8;
                   Tritium_Akim |= Tritium_Data_2[5];
                   Tritium_Akim <<= 8;
                   Tritium_Akim |= Tritium_Data_2[4];

          		    akim = Tritium_Akim;

          		memset(gelen_mesaj_kutusu,'0',sizeof(gelen_mesaj_kutusu));
              }

            else if(RX_header.StdId == 0x83 ){
            	  for( int i=0; i< sizeof(gelen_mesaj_kutusu);i++){
            		 Tritium_Data_3[i] = gelen_mesaj_kutusu[i];
            	  }

            	  	Tritium_Hiz = Tritium_Data_3[7];
            	    Tritium_Hiz <<= 8;
            	    Tritium_Hiz |= Tritium_Data_3[6];
            	    Tritium_Hiz <<= 8;
            	    Tritium_Hiz |= Tritium_Data_3[5];
            	    Tritium_Hiz <<= 8;
            	    Tritium_Hiz |= Tritium_Data_3[4];

          		    hiz = Tritium_Hiz;

          	  memset(gelen_mesaj_kutusu,'0',sizeof(gelen_mesaj_kutusu));
            }


       /*     else if (RX_header.StdId == 0x950)
              {

              	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
              	{
              		BMS_Data_1[i] = gelen_mesaj_kutusu[i];

              	}


              	BMS_Sicakligi = BMS_Data_1[3];
              	BMS_Sicakligi <<= 8;
              	BMS_Sicakligi |= BMS_Data_1[2];
              	BMS_Sicakligi <<= 8;
              	BMS_Sicakligi |= BMS_Data_1[1];
              	BMS_Sicakligi <<= 8;
              	BMS_Sicakligi |= BMS_Data_1[0];

              	sicaklik = BMS_Sicakligi;


              	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

              }*/
/*
       // Read the Battery Values BEGIN

       else if (RX_header.StdId == 0x900)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_1[i] = gelen_mesaj_kutusu[i];

         	}


         	pil1_Assign = battery_Value_1[7];
         	pil1_Assign <<= 8;
         	pil1_Assign |= battery_Value_1[6];
			pil1_Assign <<= 8;
			pil1_Assign |=  battery_Value_1[5];
			pil1_Assign <<= 8;
			pil1_Assign |= battery_Value_1[4];

			pil1 = pil1_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }


       else if (RX_header.StdId == 0x901)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_2[i] = gelen_mesaj_kutusu[i];

         	}


         	pil2_Assign = battery_Value_2[7];
         	pil2_Assign <<= 8;
         	pil2_Assign |= battery_Value_2[6];
			pil2_Assign <<= 8;
			pil2_Assign |=  battery_Value_2[5];
			pil2_Assign <<= 8;
			pil2_Assign |= battery_Value_2[4];

			pil2 = pil2_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x902)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_3[i] = gelen_mesaj_kutusu[i];

         	}


         	pil3_Assign = battery_Value_3[7];
         	pil3_Assign <<= 8;
         	pil3_Assign |= battery_Value_3[6];
			pil3_Assign <<= 8;
			pil3_Assign |=  battery_Value_3[5];
			pil3_Assign <<= 8;
			pil3_Assign |= battery_Value_3[4];

			pil3 = pil3_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x903)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_4[i] = gelen_mesaj_kutusu[i];

         	}


         	pil4_Assign = battery_Value_4[7];
         	pil4_Assign <<= 8;
         	pil4_Assign |= battery_Value_4[6];
			pil4_Assign <<= 8;
			pil4_Assign |=  battery_Value_4[5];
			pil4_Assign <<= 8;
			pil4_Assign |= battery_Value_4[4];

			pil4 = pil4_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x904)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_5[i] = gelen_mesaj_kutusu[i];

         	}


         	pil5_Assign = battery_Value_5[7];
         	pil5_Assign <<= 8;
         	pil5_Assign |= battery_Value_5[6];
			pil5_Assign <<= 8;
			pil5_Assign |=  battery_Value_5[5];
			pil5_Assign <<= 8;
			pil5_Assign |= battery_Value_5[4];

			pil5 = pil5_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x905)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_6[i] = gelen_mesaj_kutusu[i];

         	}


         	pil6_Assign = battery_Value_6[7];
         	pil6_Assign <<= 8;
         	pil6_Assign |= battery_Value_6[6];
			pil6_Assign <<= 8;
			pil6_Assign |=  battery_Value_6[5];
			pil6_Assign <<= 8;
			pil6_Assign |= battery_Value_6[4];

			pil6 = pil6_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x906)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_7[i] = gelen_mesaj_kutusu[i];

         	}


         	pil7_Assign = battery_Value_7[7];
         	pil7_Assign <<= 8;
         	pil7_Assign |= battery_Value_7[6];
			pil7_Assign <<= 8;
			pil7_Assign |=  battery_Value_7[5];
			pil7_Assign <<= 8;
			pil7_Assign |= battery_Value_7[4];

			pil7 = pil7_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x907)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_8[i] = gelen_mesaj_kutusu[i];

         	}


         	pil8_Assign = battery_Value_8[7];
         	pil8_Assign <<= 8;
         	pil8_Assign |= battery_Value_8[6];
			pil8_Assign <<= 8;
			pil8_Assign |=  battery_Value_8[5];
			pil8_Assign <<= 8;
			pil8_Assign |= battery_Value_8[4];

			pil8 = pil8_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x908)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_9[i] = gelen_mesaj_kutusu[i];

         	}


         	pil9_Assign = battery_Value_9[7];
         	pil9_Assign <<= 8;
         	pil9_Assign |= battery_Value_9[6];
			pil9_Assign <<= 8;
			pil9_Assign |=  battery_Value_9[5];
			pil9_Assign <<= 8;
			pil9_Assign |= battery_Value_9[4];

			pil9 = pil9_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x909)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_10[i] = gelen_mesaj_kutusu[i];

         	}


         	pil10_Assign = battery_Value_10[7];
         	pil10_Assign <<= 8;
         	pil10_Assign |= battery_Value_10[6];
			pil10_Assign <<= 8;
			pil10_Assign |=  battery_Value_10[5];
			pil10_Assign <<= 8;
			pil10_Assign |= battery_Value_10[4];

			pil10 = pil10_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x90A)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_11[i] = gelen_mesaj_kutusu[i];

         	}


         	pil11_Assign = battery_Value_11[7];
         	pil11_Assign <<= 8;
         	pil11_Assign |= battery_Value_11[6];
			pil11_Assign <<= 8;
			pil11_Assign |=  battery_Value_11[5];
			pil11_Assign <<= 8;
			pil11_Assign |= battery_Value_11[4];

			pil11 = pil11_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x90B)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_12[i] = gelen_mesaj_kutusu[i];

         	}


         	pil12_Assign = battery_Value_12[7];
         	pil12_Assign <<= 8;
         	pil12_Assign |= battery_Value_12[6];
			pil12_Assign <<= 8;
			pil12_Assign |=  battery_Value_12[5];
			pil12_Assign <<= 8;
			pil12_Assign |= battery_Value_12[4];

			pil12 = pil12_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x90C)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_13[i] = gelen_mesaj_kutusu[i];

         	}


         	pil13_Assign = battery_Value_13[7];
         	pil13_Assign <<= 8;
         	pil13_Assign |= battery_Value_13[6];
			pil13_Assign <<= 8;
			pil13_Assign |=  battery_Value_13[5];
			pil13_Assign <<= 8;
			pil13_Assign |= battery_Value_13[4];

			pil13 = pil13_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x90D)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_14[i] = gelen_mesaj_kutusu[i];

         	}


         	pil14_Assign = battery_Value_14[7];
         	pil14_Assign <<= 8;
         	pil14_Assign |= battery_Value_14[6];
			pil14_Assign <<= 8;
			pil14_Assign |=  battery_Value_14[5];
			pil14_Assign <<= 8;
			pil14_Assign |= battery_Value_14[4];

			pil14 = pil14_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x90E)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_15[i] = gelen_mesaj_kutusu[i];

         	}


         	pil15_Assign = battery_Value_15[7];
         	pil15_Assign <<= 8;
         	pil15_Assign |= battery_Value_15[6];
			pil15_Assign <<= 8;
			pil15_Assign |=  battery_Value_15[5];
			pil15_Assign <<= 8;
			pil15_Assign |= battery_Value_15[4];

			pil15 = pil15_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x90F)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_16[i] = gelen_mesaj_kutusu[i];

         	}


         	pil16_Assign = battery_Value_16[7];
         	pil16_Assign <<= 8;
         	pil16_Assign |= battery_Value_16[6];
			pil16_Assign <<= 8;
			pil16_Assign |=  battery_Value_16[5];
			pil16_Assign <<= 8;
			pil16_Assign |= battery_Value_16[4];

			pil16 = pil16_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x910)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_17[i] = gelen_mesaj_kutusu[i];

         	}


         	pil17_Assign = battery_Value_17[7];
         	pil17_Assign <<= 8;
         	pil17_Assign |= battery_Value_17[6];
			pil17_Assign <<= 8;
			pil17_Assign |=  battery_Value_17[5];
			pil17_Assign <<= 8;
			pil17_Assign |= battery_Value_17[4];

			pil17 = pil17_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x911)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_18[i] = gelen_mesaj_kutusu[i];

         	}


         	pil18_Assign = battery_Value_18[7];
         	pil18_Assign <<= 8;
         	pil18_Assign |= battery_Value_18[6];
			pil18_Assign <<= 8;
			pil18_Assign |=  battery_Value_18[5];
			pil18_Assign <<= 8;
			pil18_Assign |= battery_Value_18[4];

			pil18 = pil18_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x912)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_19[i] = gelen_mesaj_kutusu[i];

         	}


         	pil19_Assign = battery_Value_19[7];
         	pil19_Assign <<= 8;
         	pil19_Assign |= battery_Value_19[6];
			pil19_Assign <<= 8;
			pil19_Assign |=  battery_Value_19[5];
			pil19_Assign <<= 8;
			pil19_Assign |= battery_Value_19[4];

			pil19 = pil19_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x913)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_20[i] = gelen_mesaj_kutusu[i];

         	}


         	pil20_Assign = battery_Value_20[7];
         	pil20_Assign <<= 8;
         	pil20_Assign |= battery_Value_20[6];
			pil20_Assign <<= 8;
			pil20_Assign |=  battery_Value_20[5];
			pil20_Assign <<= 8;
			pil20_Assign |= battery_Value_20[4];

			pil20 = pil20_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }


       else if (RX_header.StdId == 0x914)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_21[i] = gelen_mesaj_kutusu[i];

         	}


         	pil21_Assign = battery_Value_21[7];
         	pil21_Assign <<= 8;
         	pil21_Assign |= battery_Value_21[6];
			pil21_Assign <<= 8;
			pil21_Assign |=  battery_Value_21[5];
			pil21_Assign <<= 8;
			pil21_Assign |= battery_Value_21[4];

			pil21 = pil21_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x915)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_22[i] = gelen_mesaj_kutusu[i];

         	}


         	pil22_Assign = battery_Value_22[7];
         	pil22_Assign <<= 8;
         	pil22_Assign |= battery_Value_22[6];
			pil22_Assign <<= 8;
			pil22_Assign |=  battery_Value_22[5];
			pil22_Assign <<= 8;
			pil22_Assign |= battery_Value_22[4];

			pil22 = pil22_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x916)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_23[i] = gelen_mesaj_kutusu[i];

         	}


         	pil23_Assign = battery_Value_23[7];
         	pil23_Assign <<= 8;
         	pil23_Assign |= battery_Value_23[6];
         	pil23_Assign <<= 8;
         	pil23_Assign |=  battery_Value_23[5];
         	pil23_Assign <<= 8;
         	pil23_Assign |= battery_Value_23[4];

			pil23 = pil23_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x917)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_24[i] = gelen_mesaj_kutusu[i];

         	}


         	pil24_Assign = battery_Value_24[7];
         	pil24_Assign <<= 8;
         	pil24_Assign |= battery_Value_24[6];
         	pil24_Assign <<= 8;
         	pil24_Assign |=  battery_Value_24[5];
         	pil24_Assign <<= 8;
         	pil24_Assign |= battery_Value_24[4];

			pil24 = pil24_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }
       else if (RX_header.StdId == 0x918)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_25[i] = gelen_mesaj_kutusu[i];

         	}


         	pil25_Assign = battery_Value_25[7];
         	pil25_Assign <<= 8;
         	pil25_Assign |= battery_Value_25[6];
         	pil25_Assign <<= 8;
         	pil25_Assign |=  battery_Value_25[5];
         	pil25_Assign <<= 8;
         	pil25_Assign |= battery_Value_25[4];

			pil25 = pil25_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x919)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_26[i] = gelen_mesaj_kutusu[i];

         	}


         	pil26_Assign = battery_Value_26[7];
         	pil26_Assign <<= 8;
         	pil26_Assign |= battery_Value_26[6];
         	pil26_Assign <<= 8;
         	pil26_Assign |=  battery_Value_26[5];
         	pil26_Assign <<= 8;
         	pil26_Assign |= battery_Value_26[4];

			pil26 = pil26_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x91A)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_27[i] = gelen_mesaj_kutusu[i];

         	}


         	pil27_Assign = battery_Value_27[7];
         	pil27_Assign <<= 8;
         	pil27_Assign |= battery_Value_27[6];
         	pil27_Assign <<= 8;
			pil27_Assign |=  battery_Value_27[5];
			pil27_Assign <<= 8;
			pil27_Assign |= battery_Value_27[4];

			pil27 = pil27_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x91B)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_28[i] = gelen_mesaj_kutusu[i];

         	}


         	pil28_Assign = battery_Value_28[7];
         	pil28_Assign <<= 8;
         	pil28_Assign |= battery_Value_28[6];
         	pil28_Assign <<= 8;
         	pil28_Assign |=  battery_Value_28[5];
         	pil28_Assign <<= 8;
         	pil28_Assign |= battery_Value_28[4];

			pil28 = pil28_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x91C)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_29[i] = gelen_mesaj_kutusu[i];

         	}


         	pil29_Assign = battery_Value_29[7];
         	pil29_Assign <<= 8;
         	pil29_Assign |= battery_Value_29[6];
         	pil29_Assign <<= 8;
         	pil29_Assign |=  battery_Value_29[5];
         	pil29_Assign <<= 8;
         	pil29_Assign |= battery_Value_29[4];

			pil29 = pil29_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x91D)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_30[i] = gelen_mesaj_kutusu[i];

         	}


         	pil30_Assign = battery_Value_30[7];
         	pil30_Assign <<= 8;
         	pil30_Assign |= battery_Value_30[6];
			pil30_Assign <<= 8;
			pil30_Assign |=  battery_Value_30[5];
			pil30_Assign <<= 8;
			pil30_Assign |= battery_Value_30[4];

			pil30 = pil30_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x91E)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_31[i] = gelen_mesaj_kutusu[i];

         	}


         	pil31_Assign = battery_Value_31[7];
         	pil31_Assign <<= 8;
         	pil31_Assign |= battery_Value_31[6];
			pil31_Assign <<= 8;
			pil31_Assign |=  battery_Value_31[5];
			pil31_Assign <<= 8;
			pil31_Assign |= battery_Value_31[4];

			pil31 = pil31_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       else if (RX_header.StdId == 0x91F)
       {

         	for (int i = 0 ; i < sizeof(gelen_mesaj_kutusu) ; i++)
         	{
         		battery_Value_32[i] = gelen_mesaj_kutusu[i];

         	}


         	pil32_Assign = battery_Value_32[7];
         	pil32_Assign <<= 8;
         	pil32_Assign |= battery_Value_32[6];
			pil32_Assign <<= 8;
			pil32_Assign |=  battery_Value_32[5];
			pil32_Assign <<= 8;
			pil32_Assign |= battery_Value_32[4];

			pil32 = pil32_Assign;


         	memset(&gelen_mesaj_kutusu, 0, sizeof(gelen_mesaj_kutusu));

       }

       // Read the Battery Values END
*/

  /* USER CODE END CAN_RX1_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

