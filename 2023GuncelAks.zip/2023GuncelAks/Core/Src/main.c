/* USER CODE BEGIN Header */

/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc2;
ADC_HandleTypeDef hadc3;

CAN_HandleTypeDef hcan;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart5;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_UART4_Init(void);
static void MX_UART5_Init(void);
static void MX_CAN_Init(void);
static void MX_ADC3_Init(void);
static void MX_TIM2_Init(void);
static void MX_ADC2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t gelen_mesaj_kutusu[6];
uint8_t gelenData_1[6];
uint8_t gelenData_2[6];
uint8_t gelenData_3[6];
uint8_t gelenData_4[6];
uint8_t gelenData_5[6];
uint8_t gelenData_6[6];
uint8_t gelenData_7[6];
uint8_t gelenData_8[6];
uint8_t gelenData_9[6];
uint8_t gelenData_10[6];
uint8_t gelenData_11[6];
uint8_t gelenData_12[6];
uint8_t gelenData_13[6];
uint8_t gelenData_14[6];
uint8_t gelenData_15[6];
uint8_t gelenData_16[6];
uint8_t gelenData_17[6];
uint8_t gelenData_18[6];
uint8_t gelenData_19[6];
uint8_t gelenData_20[6];
uint8_t gelenData_21[6];
uint8_t gelenData_22[6];
uint8_t gelenData_23[6];
uint8_t gelenData_24[6];
uint8_t gelenData_25[6];
uint8_t gelenData_26[6];
uint8_t gelenData_27[6];
uint8_t gelenData_28[6];
uint8_t gelenData_29[6];
uint8_t gelenData_30[6];
uint8_t gelenData_31[6];
uint8_t gelenData_32[6];
uint8_t gelenData_33[6];
uint8_t gelenData_34[6];
uint8_t gelenData_35[6];
uint8_t gelenData_36[6];
uint8_t gelenData_37[6];
uint8_t gelenData_38[6];
uint8_t gelenData_39[6];
uint8_t gelenData_40[6];
uint8_t gelenData_41[6];
uint8_t gelenData_42[6];
uint8_t gelenData_43[6];
uint8_t gelenData_44[6];
uint8_t gelenData_45[6];


float pil1;
float pil2;
float pil3;
float pil1;
float pil2;
float pil3;
float pil4;
float pil5;
float pil6;
float pil7;
float pil8;
float pil9;
float pil10;
float pil11;
float pil12;
float pil13;
float pil14;
float pil15;
float pil16;
float pil17;
float pil18;
float pil19;
float pil20;
float pil21;
float pil22;
float pil23;
float pil24;
float pil25;
float pil26;
float pil27;
float pil28;
float pil29;
float pil30;
float pil31;
float pil32;
float pil33;
float pil34;
float pil35;
float pil36;
float pil37;
float pil38;
float hiz;
float hizkmh;
float adc10;
float fazakim;
float akim;
float max_akim;
float sicaklik;
float Motor_Sicakligi;
float gerilim;
float guc;
float batarya;
float speed;
float avg;
float avg_;
float adc_pedal_akim;
float adc_pot_hiz;
float adc2;
float gpinput;
float bmsakim;
int silecekdurum = 0;
float kalanenerji;
/*Tritiuma TX özel tanımlamaları*/
float rpm;
float rpmtokmh;
float current;
int current2;
float BMS_Sicakligi;
float WH_enerji;
float bataryavolt;
float bataryagerilim;
float SOC;
float BATAKIM;
float sarjorani;
float batakimvalue;

uint8_t bmsTemp_Counter = 1;

uint32_t wiper_counter = 0;


// Battery Values BEGIN

float pil1;
float pil2;
float pil3;
float pil4;
float pil5;
float pil6;
float pil7;
float pil8;
float pil9;
float pil10;
float pil11;
float pil12;
float pil13;
float pil14;
float pil15;
float pil16;
float pil17;
float pil18;
float pil19;
float pil20;
float pil21;
float pil22;
float pil23;
float pil24;
float pil25;
float pil26;
float pil27;
float pil28;
float pil29;
float pil30;
float pil31;
float pil32;


float pil1_Assign;
float pil2_Assign;
float pil3_Assign;
float pil4_Assign;
float pil5_Assign;
float pil6_Assign;
float pil7_Assign;
float pil8_Assign;
float pil9_Assign;
float pil10_Assign;
float pil11_Assign;
float pil12_Assign;
float pil13_Assign;
float pil14_Assign;
float pil15_Assign;
float pil16_Assign;
float pil17_Assign;
float pil18_Assign;
float pil19_Assign;
float pil20_Assign;
float pil21_Assign;
float pil22_Assign;
float pil23_Assign;
float pil24_Assign;
float pil25_Assign;
float pil26_Assign;
float pil27_Assign;
float pil28_Assign;
float pil29_Assign;
float pil30_Assign;
float pil31_Assign;
float pil32_Assign;


// Coding for wiper variable
volatile uint32_t buttonstatusWiper;


uint8_t battery_Value_1[8];
uint8_t battery_Value_2[8];
uint8_t battery_Value_3[8];
uint8_t battery_Value_4[8];
uint8_t battery_Value_5[8];
uint8_t battery_Value_6[8];
uint8_t battery_Value_7[8];
uint8_t battery_Value_8[8];
uint8_t battery_Value_9[8];
uint8_t battery_Value_10[8];
uint8_t battery_Value_11[8];
uint8_t battery_Value_12[8];
uint8_t battery_Value_13[8];
uint8_t battery_Value_14[8];
uint8_t battery_Value_15[8];
uint8_t battery_Value_16[8];
uint8_t battery_Value_17[8];
uint8_t battery_Value_18[8];
uint8_t battery_Value_19[8];
uint8_t battery_Value_20[8];
uint8_t battery_Value_21[8];
uint8_t battery_Value_22[8];
uint8_t battery_Value_23[8];
uint8_t battery_Value_24[8];
uint8_t battery_Value_25[8];
uint8_t battery_Value_26[8];
uint8_t battery_Value_27[8];
uint8_t battery_Value_28[8];
uint8_t battery_Value_29[8];
uint8_t battery_Value_30[8];
uint8_t battery_Value_31[8];
uint8_t battery_Value_32[8];

// Battery Values END


// DMA ADC icin tanımlamalar
uint16_t adc3_Value[4];
uint32_t adc1end = 0;


/*Tritiuma RX özel tanımlamaları*/
float Tritium_Hiz;
float Tritium_Voltage;
float Tritium_Akim;
float Tritium_Motorsicakligi;
float Tritium_Yuzeysicakligi;


#define ADC_MAX_COUNT	100
int adcValues[ADC_MAX_COUNT];
int adcIx=0;

#define ADC_MAX_COUNT_	100
int adc_Values[ADC_MAX_COUNT_];
int adc_Ix=0;

#define MC_CAN_BASE 0x80// HIGH = SERIAL NUMBER LOW = "TRIa" STRING // BİZİM TIRITUM 0x400; TWENTE TRITIUM 0x80
#define MC_LIMITS   0x01    // High = Active Motor/CAN counts   Low = Error & Limit flags
#define MC_BUS      0x02    // High = Bus Current               Low = Bus Voltage
#define MC_VELOCITY   0x03    // High = Velocity (m/s)            Low = Velocity (rpm)
#define MC_PHASE    0x04    // High = Phase A Current           Low = Phase B Current
#define MC_V_VECTOR   0x05    // High = Vd vector                 Low = Vq vector
#define MC_I_VECTOR   0x06    // High = Id vector                 Low = Iq vector
#define MC_BEMF_VECTOR  0x07    // High = BEMFd vector              Low = BEMFq vector
#define MC_RAIL1    0x08    // High = 15V                       Low = Unused
#define MC_RAIL2    0x09    // High = 3.3V                      Low = 1.9V
#define MC_FAN      0x0A    // High = Reserved                  Low = Reserved
#define MC_TEMP1    0x0B    // High = Heatsink Phase C Temp     Low = Motor Temp
#define MC_TEMP2    0x0C    // High = Heatsink Phase B Temp     Low = CPU Temp
#define MC_TEMP3    0x0D    // High = Heatsink Phase A Temp     Low = Unused
#define MC_CUMULATIVE 0x0E    // High = DC Bus AmpHours           Low = Odometer

/* TRITIUMU KONTROL ETMEK İÇİN GEREKLİ BASE ADRESLERİNİ TANIMADIK */

#define DC_CAN_BASE     0x340 // bizim tritium 0x500, twente tritium 0x340
#define DC_DRIVE        0x341
#define DC_POWER    	0x342

/* YUKARIDA TRITIUMU KONTROL ETMEK İÇİN GEREKEN BASE ADRESLERİ İÇİN DATA YOU BELİRLEMEMEMİZ GEREKİR */

CAN_TxHeaderTypeDef TX_CAN_BASE; // GİDEN DATA İÇİN TANIMLAMA YAPTIK
CAN_TxHeaderTypeDef TX_DRIVE; // GİDEN DATA İÇİN TANIMLAMA YAPTIK
CAN_TxHeaderTypeDef TX_POWER; // GİDEN DATA İÇİN TANIMLAMA YAPTIK

/* GELEN DATA HAVUZU VE GİDEN DATA HAVUZU TANIMLADIK */

uint8_t Tritium_Data_1[8];
uint8_t Tritium_Data_2[8];
uint8_t Tritium_Data_3[8];
uint8_t Tritium_Data_4[8];

uint8_t BMS_Data_1[8];
uint8_t WH_Data_1[8];
uint8_t BAT_Data_1[8];
uint8_t SARJ_Data_1[8];
uint8_t BATAKIM_Data_1[8];

uint8_t Tritium_Giden_1[8]; // GİDEN DATA HAVUZU
uint8_t Tritium_Giden_2[8];
uint8_t Tritium_Giden_3[8];



uint32_t pTxMailbox;  // TX POINTER
uint32_t pRxMailbox;  // RX POINTER
CAN_RxHeaderTypeDef RX_header;



volatile uint32_t buttonDurum;
volatile uint32_t sayac = 4;


int id;
int counter = 0;
uint8_t send[99];
uint8_t sub_Step  = 1;
uint8_t success_Step = 1;
uint8_t currend_Step = 0;
uint32_t begin_Time;
uint32_t time_Out;
int direct_counter=0;
int durum = 0;
volatile uint8_t gelen_byte;
volatile uint8_t xBee_gln[10];
volatile uint8_t Rx_indx = 0;


/************************************************/
char rxBuf[1];
int a=0;
int b=0;
int x;
uint16_t Global_Counter = 0;
bool tim = false;
uint8_t Cmd_End[3] = {0xFF,0xFF,0xFF};
uint8_t Cmd_End_[3] = {0xFF,0xFF,0xFF};



void SendtoGauge (char *obj, float num, int dp)
{
	uint32_t number = num*(pow(10,dp));


	uint8_t *buffer = malloc(30*sizeof(char));


	int len = sprintf((char *)buffer, "%s.val=%d", obj,number);


	HAL_UART_Transmit(&huart5, buffer, len, 99);

	HAL_UART_Transmit(&huart5, Cmd_End, 3, 100);


	free(buffer);

}


void SendtoGaugeNegatif (char *obj, float num, int dp)
{
	 int number = num*(pow(10,dp));


	 uint8_t *buffer = malloc(30*sizeof(char));

	 int len = sprintf((char *)buffer, "%s.val=%d", obj,number);


	 HAL_UART_Transmit(&huart5, buffer, len, 99);

	 HAL_UART_Transmit(&huart5, Cmd_End, 3, 100);


	 free(buffer);

}


void NEXTION_SendString (char *ID, char *string)
{
	char buf[50];

	int len=sprintf(buf, "%s.txt=\"%s\"", ID, string);


	HAL_UART_Transmit(&huart5, (uint8_t *)buf, len, 1000);

	HAL_UART_Transmit(&huart5, Cmd_End, 3, 1000);

}


enum anlik
{
	  hizt,
	  fazakimt,
	  akimt,
	  sicaklikt,
	  motorsicaklikt,
	  gerilimt,
      şarz_oranıt,
	  güçt,
	  pilt_1,
	  pilt_2,
	  pilt_3,
	  pilt_4,
	  pilt_5,
	  pilt_6,
	  pilt_7,
	  pilt_8,
	  pilt_9,
	  pilt_10,
	  pilt_11,
	  pilt_12,
	  pilt_13,
	  pilt_14,
	  pilt_15,
	  pilt_16,
	  pilt_17,
	  pilt_18,
	  pilt_19,
	  pilt_20,
	  pilt_21,
	  pilt_22,
	  pilt_23,
	  pilt_24,
	  pilt_25,
	  pilt_26,
	  pilt_27,
	  pilt_28,
	  pilt_29,
	  pilt_30,
	  pilt_31,
	  pilt_32,
	  pilt_33,
	  pilt_34,
	  pilt_35,
	  pilt_36,
	  pilt_37,
	  pilt_38,
	  ANLIK_WAIT,
	  DUR

};


void Set_Windshield(uint32_t angle)
{
	uint32_t pulse_width = 0;


	if (angle > 120)
	{
		angle = 120;

	}


	else if (angle < 0)
	{
		angle = 0;

	}


	if (angle == 60) // Center Position
	{
		pulse_width = 75;

	}
	else if (angle < 60) // CW Position
	{
		pulse_width = 45 + (angle * 1 / 2);

	}
	else // CCW Position
	{
		pulse_width = 45 + (angle * 1 / 2);

	}
	TIM2 -> CCR1 = pulse_width;

}


void Windshield_Control(void)
{
	buttonstatusWiper = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
	if (buttonstatusWiper == 0)
	{
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);

		Set_Windshield(120);

		HAL_Delay(600);

     	Set_Windshield(0);

		HAL_Delay(600);

		Set_Windshield(60);

		HAL_Delay(600);

	}


	else if (buttonstatusWiper == 1)
	{
		HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);


		wiper_counter = 0;

	}

}


/*

void adcpotoku_pedal_akim(void)
{
	HAL_ADC_Start_DMA(&hadc3, (uint32_t *) &adc3_Value, 16);


    for (b =0 ; b < 4 ; b++)
    {
    	adc1end += adc3_Value[b];

    }


	HAL_ADC_PollForConversion(&hadc3,255);


	adc10 = adc3_Value[0];

	adc3_Value[0] = ((adc3_Value[0] - 950) / (2900 - 950.0f));


	 if(adc3_Value[0] <= 0.06)
	 {
		 adc3_Value[0] = 0;

	 }


	 if(adc3_Value[0] >= 1)
	 {
		 adc3_Value[0] = 1;

	 }



	 HAL_ADC_Stop_DMA(&hadc3);


	 // adc2 = 10;

	 current = adc3_Value[0] * 0.2;

	 // current=0;

}

*/

void adcpotoku_pedal_akim()
{
 	HAL_ADC_Start(&hadc3);


 	HAL_ADC_PollForConversion(&hadc3,255);


 	adc_pedal_akim = HAL_ADC_GetValue(&hadc3);

 	adc10=adc_pedal_akim;

 	adc_pedal_akim = ((adc_pedal_akim-950)/(2900-950.0f));


 	if(adc_pedal_akim<=0.06)
 	{
 		adc_pedal_akim=0;

    }


 	if(adc_pedal_akim>=1)
 	{
 		adc_pedal_akim=1;
    }


 	HAL_ADC_Stop(&hadc3);


 	if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_4) == GPIO_PIN_SET)
 	{

        //buton kapalı
 		max_akim = 0.4;

 		SendtoGauge("maxakim",max_akim,1);

 		current=adc_pedal_akim*0.4;

 	}


 	else if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_4) == GPIO_PIN_RESET)
    {
 		//buton açık
 		max_akim = 1.0;

 		SendtoGauge("maxakim",max_akim,1);

 		current=adc_pedal_akim*1.0;

 	}

}


void adcpotoku_hiz()
{
 	HAL_ADC_Start(&hadc2);


 	HAL_ADC_PollForConversion(&hadc2,255);


 	adc_pot_hiz = HAL_ADC_GetValue(&hadc2);


 	HAL_ADC_Stop(&hadc2);


 	rpm=adc_pot_hiz ;

}



/*

void FlasherControl(void)
{

	if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7) == GPIO_PIN_SET)
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);

	}


	else if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7) == GPIO_PIN_RESET)
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);

	}

}

*/


void gearControl(void)
{
	buttonDurum = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6);


	if (buttonDurum == GPIO_PIN_SET)
	{
		//buton kapalı

		// ileri gider (teker sağda)
		NEXTION_SendString("rejen", "ileri");

	}


	else if (buttonDurum == GPIO_PIN_RESET)
	{
		rpm = (-1) * rpm;

		NEXTION_SendString("rejen", "geri");

		//buton açık
		 //geri gider (teker solda)

	}

}


void surus(void)
{

	adc2=9999;

 	memcpy(&Tritium_Giden_1[4], &current, sizeof(float));

 	memcpy(&Tritium_Giden_1[0], &rpm, sizeof(float));


 	if( HAL_CAN_AddTxMessage(&hcan, &TX_DRIVE,Tritium_Giden_1, &pTxMailbox) != HAL_OK )
 	{
 		//Error_Handler();
 	}
 	//while(HAL_CAN_GetTxMailboxesFreeLevel(&hcan)!=3);

 	//CANmsg_3
 	float buscurrent = 1.0;

 	Tritium_Giden_2[0] = 0;
 	Tritium_Giden_2[1] = 0;
 	Tritium_Giden_2[2] = 0;
 	Tritium_Giden_2[3] = 0;

 	memcpy(&Tritium_Giden_2[4], &buscurrent, sizeof(float));


 	if( HAL_CAN_AddTxMessage(&hcan, &TX_POWER, Tritium_Giden_2, &pTxMailbox) != HAL_OK )
 	{
 		//Error_Handler();
 	}
 	//while(HAL_CAN_GetTxMailboxesFreeLevel(&hcan)!=3);


 	//CANmsg_1 0x500
 	int serialNumber = 5765;

 	memcpy(&Tritium_Giden_3[0], &serialNumber, sizeof(uint32_t));

 	Tritium_Giden_3[4]='6';
 	Tritium_Giden_3[5]='8';
 	Tritium_Giden_3[6]='0';
 	Tritium_Giden_3[7]='T';


 	if( HAL_CAN_AddTxMessage(&hcan, &TX_CAN_BASE,Tritium_Giden_3, &pTxMailbox) != HAL_OK)
 	{
 		//Error_Handler();
 	}

}


void Bms_Temp_Control(void)
{

	if ((sicaklik < 70.0f) && (bmsTemp_Counter = 1))
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);


        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET);


        bmsTemp_Counter = 0; // 1 KEZ RESETLENDİ.

	}


	else if ((sicaklik >= 70.0f) && (bmsTemp_Counter = 0))
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);


		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);


		bmsTemp_Counter = 1; // 1 KEZ SİSTEM ALARMI TETİKLENDİ.

	}

}




/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  MX_CAN_Init();
  MX_ADC3_Init();
  MX_TIM2_Init();
  MX_ADC2_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);

	 adcpotoku_pedal_akim();
	 adcpotoku_hiz();
	 gearControl();

	 hizkmh = hiz*(3.6);
	 hizkmh = (int)hizkmh;

		sprintf(send, "@H=%d\r\n", (int) hizkmh); // +++
		HAL_UART_Transmit(&huart4, (uint8_t *) send, sizeof(send), 8);


	 	 sprintf(send, "@S=%d\r\n", (int) sicaklik); // +++
	 	 HAL_UART_Transmit(&huart4, (uint8_t *) send, sizeof(send), 8);


	 	 sprintf(send, "@G=%d\r\n", (int) gerilim); // +++
	 	 HAL_UART_Transmit(&huart4, (uint8_t *) send, sizeof(send), 8);


	 	 sprintf(send, "@W=%d\r\n", (int) kalanenerji); // ---
	 	 HAL_UART_Transmit(&huart4, (uint8_t *) send, sizeof(send), 8);


	 	 sprintf(send, "@N=%d\r\n", (int) current); // +++
	 	 HAL_UART_Transmit(&huart4, (uint8_t *) send, sizeof(send), 8);


	 	current2=(10*current)/0.4;
	 	rpmtokmh = 0.12 * 3.14 * 0.257 * rpm;
	 	if ( rpmtokmh < 0 ){
	 		rpmtokmh = (-1) * rpmtokmh;
	 	}
	 	rpmtokmh = (int)rpmtokmh;

	/* 	akim=999.9;
	 	hizkmh=999.9;
	 	gerilim=999.9;
	 	kalanenerji=999.9;
	 	sicaklik=999.9;
	 	current2=100;
	 	rpmtokmh=999.9;
	 	bataryagerilim=999.9;

	 	sarjorani=100;
	 	batakimvalue=999.9;*/



	SendtoGauge("akim",akim,1);

	SendtoGaugeNegatif("hiz",hizkmh,1);

	SendtoGauge("gerilim",gerilim,1);

	SendtoGauge("batarya",kalanenerji,1);

	SendtoGauge("sicaklik",sicaklik,1);

	SendtoGauge("pedal",current2,1);

	SendtoGauge("maxhiz",rpmtokmh,1);

	SendtoGauge("bataryagerilim",bataryagerilim,1);

	SendtoGauge("sarjorani",sarjorani,1);

	SendtoGaugeNegatif("batakim",batakimvalue,1);


	Windshield_Control(); // Open the windshield


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_UART4|RCC_PERIPHCLK_UART5
                              |RCC_PERIPHCLK_ADC12|RCC_PERIPHCLK_ADC34
                              |RCC_PERIPHCLK_TIM2;
  PeriphClkInit.Uart4ClockSelection = RCC_UART4CLKSOURCE_PCLK1;
  PeriphClkInit.Uart5ClockSelection = RCC_UART5CLKSOURCE_PCLK1;
  PeriphClkInit.Adc12ClockSelection = RCC_ADC12PLLCLK_DIV1;
  PeriphClkInit.Adc34ClockSelection = RCC_ADC34PLLCLK_DIV1;
  PeriphClkInit.Tim2ClockSelection = RCC_TIM2CLK_HCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */
  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc2.Init.Resolution = ADC_RESOLUTION_10B;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.ContinuousConvMode = ENABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_11;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.SamplingTime = ADC_SAMPLETIME_601CYCLES_5;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

/**
  * @brief ADC3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC3_Init(void)
{

  /* USER CODE BEGIN ADC3_Init 0 */

  /* USER CODE END ADC3_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC3_Init 1 */

  /* USER CODE END ADC3_Init 1 */
  /** Common config
  */
  hadc3.Instance = ADC3;
  hadc3.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc3.Init.Resolution = ADC_RESOLUTION_12B;
  hadc3.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc3.Init.ContinuousConvMode = ENABLE;
  hadc3.Init.DiscontinuousConvMode = DISABLE;
  hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc3.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc3.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc3.Init.NbrOfConversion = 1;
  hadc3.Init.DMAContinuousRequests = DISABLE;
  hadc3.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc3.Init.LowPowerAutoWait = DISABLE;
  hadc3.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc3) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc3, &multimode) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_12;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC3_Init 2 */

  /* USER CODE END ADC3_Init 2 */

}

/**
  * @brief CAN Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN_Init(void)
{

  /* USER CODE BEGIN CAN_Init 0 */

  /* USER CODE END CAN_Init 0 */

  /* USER CODE BEGIN CAN_Init 1 */

  /* USER CODE END CAN_Init 1 */
  hcan.Instance = CAN;
  hcan.Init.Prescaler = 2;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_15TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = DISABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN_Init 2 */
  TX_CAN_BASE.DLC = 8;
       	  TX_CAN_BASE.IDE = CAN_ID_STD;
       	  TX_CAN_BASE.RTR = CAN_RTR_DATA;
       	  TX_CAN_BASE.StdId = 0x340;

       	  TX_DRIVE.DLC = 8;
       	  TX_DRIVE.IDE = CAN_ID_STD;
       	  TX_DRIVE.RTR = CAN_RTR_DATA;
       	  TX_DRIVE.StdId = 0x341;

       	  TX_POWER.DLC = 8;
       	  TX_POWER.IDE = CAN_ID_STD;
       	  TX_POWER.RTR = CAN_RTR_DATA;
       	  TX_POWER.StdId = 0x342;

     ///////////////////////////////////////////////////

       	 /* İBRAHİM ABE BASE ADRESS */
       	     		  RX_header.StdId = 0x911;
       	     		  RX_header.IDE = CAN_ID_STD;
       	     		  RX_header.RTR = CAN_RTR_DATA;

       	  	  /* TRİTİUM BASE ADRESS */
       		  RX_header.StdId = 0x80;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  /* TRİTİUM MOTOR VE YÜZEY SICAKLIK ADRESİ  */
       		  RX_header.StdId = 0x8B;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  /* ACTİVE MOTOR / ERROR */
       		  RX_header.StdId = 0x81;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  /* TRİTİUM GERİLİM VE AKIM ADRESİ */
       		  RX_header.StdId = 0x82;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  /* TRİTİUM HIZ ADRESİ */
       		  RX_header.StdId = 0x83;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;
////////////////////////////////////////////////////////////////////////
       		  // BMS Temperature
       		  RX_header.StdId = 0x650;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

			  // BMS Wh
			  RX_header.StdId = 0x651;
			  RX_header.IDE = CAN_ID_STD;
			  RX_header.RTR = CAN_RTR_DATA;

			// BMS bataryagerilim
			RX_header.StdId = 0x652;
			RX_header.IDE = CAN_ID_STD;
			RX_header.RTR = CAN_RTR_DATA;

			// BMS sarjorani
						RX_header.StdId = 0x653;
						RX_header.IDE = CAN_ID_STD;
						RX_header.RTR = CAN_RTR_DATA;

			// BMS bataryaakim
			RX_header.StdId = 0x654;
			RX_header.IDE = CAN_ID_STD;
			RX_header.RTR = CAN_RTR_DATA;

       		  // BATTERY VALUE FILTER BEGIN
       		  RX_header.StdId = 0x600;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x601;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x602;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x603;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x604;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x605;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x606;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x607;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x608;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x609;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x60A;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x60B;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x60C;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x60D;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x60E;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x60F;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x610;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x611;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x612;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x613;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x614;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x615;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x616;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x617;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x618;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x619;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x61A;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x61B;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x61C;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x61D;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x61E;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  RX_header.StdId = 0x61F;
       		  RX_header.IDE = CAN_ID_STD;
       		  RX_header.RTR = CAN_RTR_DATA;

       		  // BATTERY VALUE FILTER END

       		 CAN_FilterTypeDef  sFilterConfig;

       		 	  sFilterConfig.FilterBank = 0;
       		 	  sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
       		 	  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
       		 	  sFilterConfig.FilterIdHigh = 0x0000;
       		 	  sFilterConfig.FilterIdLow = 0x0000;
       		 	  sFilterConfig.FilterMaskIdHigh = 0x0000;
       		 	  sFilterConfig.FilterMaskIdLow = 0x0000;
       		 	  sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
       		 	  sFilterConfig.FilterActivation = ENABLE;
       		 	  sFilterConfig.SlaveStartFilterBank = 14;

       		 	  if(HAL_CAN_ConfigFilter(&hcan, &sFilterConfig) != HAL_OK)
       		 	  {

       		 		//Error_Handler();
       		 	  }


       		 	  if (HAL_CAN_Start(&hcan) != HAL_OK)
       		 	  {


       		 	    //Error_Handler();
       		 	  }


       		 	  if (HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
       		 	  {

       		 	    //Error_Handler();
       		 	  }

  /* USER CODE END CAN_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 719;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 9600;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 9600;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  huart5.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart5.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(Led_test_GPIO_Port, Led_test_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : Led_test_Pin */
  GPIO_InitStruct.Pin = Led_test_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(Led_test_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : Y_n_butonu_Pin */
  GPIO_InitStruct.Pin = Y_n_butonu_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(Y_n_butonu_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PC4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PB12 */
  GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PC7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/*
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{

  if(GPIO_Pin == GPIO_PIN_4)
  {
    wiperOpen();

  }

}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{

  if(htim -> Instance == TIM2)
  {


  }

}
*/

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {

  }


  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

